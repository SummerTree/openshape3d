# Fixture regeneration

The delivered STEP files are immediately usable. Regeneration is optional and uses only original geometry recipes with public OCCT APIs.

`generate_fixtures.cpp` targets the pinned repository's OCCT 7.8.1 Mac Catalyst library. It builds shapes directly, verifies mathematical volumes, writes AP214 STEP, reads the files back, and checks validity/count/volume. It also writes six binary STL files with intended units mm, linear deflection 0.02 mm and angular deflection 0.15 radians.

Run from the repository root on Apple Silicon with Xcode installed and the real Git LFS OCCT libraries present:

```sh
xcrun -sdk macosx clang++ -target arm64-apple-ios17.0-macabi \
  -std=c++17 -O1 \
  -I ThirdParty/OCCT.xcframework/ios-arm64/Headers \
  docs/qa/shapr3d-parity/tools/generate_fixtures.cpp \
  ThirdParty/OCCT.xcframework/ios-arm64-maccatalyst/libOCCT-MAC_CATALYST_ARM64.a \
  -o /tmp/openshape-generate-fixtures
```

Use a new output folder so frozen baseline files are preserved:

```sh
mkdir -p /tmp/openshape-fixtures-new
/tmp/openshape-generate-fixtures /tmp/openshape-fixtures-new
```

The iOS header directory is used because it contains the complete public headers in this checkout; the linked binary is the Catalyst slice. The command-line host explicitly closes logs and exits without Catalyst static-library teardown, which otherwise crashes after successful completion outside a UIKit application. This host-specific behavior is isolated to the fixture utility and does not modify app code. A reported validation/transfer error aborts generation before the final success exit.

STEP headers contain generation timestamps, so byte hashes may change across regenerations. Freeze exact distributed files and their checksums. Compare semantic geometry and expected values, not generated timestamp bytes. If replacing a fixture, review and regenerate its manifest/hash in a separate baseline revision; never overwrite an accepted reference with an app output to make a test pass.

The raw `occt_validation.csv` records actual file topology. Different kernels can split equivalent surfaces differently. Its face counts are diagnostic rather than a universal equivalence gate.

The two DXFs and four negative fixtures were generated from simple explicit coordinates/bytes for this pack. Their intended geometry or failure outcomes and hashes are in `fixture_manifest.json`. They can be kept as frozen inputs without regenerating them. The renderer/Word authoring utilities used to prepare the handoff are not app tests.
